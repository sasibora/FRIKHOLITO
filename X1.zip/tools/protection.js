/**
 * protection.js
 * * This script provides client-side protection for web pages. It checks if a user 
 * has successfully logged in by looking for a specific flag in the browser's
 * sessionStorage.
 *
 * How it works:
 * 1. The script runs immediately when a page is loaded.
 * 2. It checks for the existence and value of `sessionStorage.getItem('isLoggedIn')`.
 * 3. This 'isLoggedIn' flag is set to 'true' only by the central `login.html` page 
 * after a user enters a valid access code.
 * 4. If the flag is not 'true', it means the user has not logged in during their
 * current browser session.
 * 5. In that case, the script redirects the user to `login.html`. It also appends the
 * current page's URL as a parameter (`?redirect=...`). This allows the login page
 * to send the user back to the correct page after they successfully log in.
 *
 * Usage:
 * - Place this file in the same directory as your protected HTML files and `login.html`.
 * - Add `<script src="protection.js"></script>` to the top of the `<body>` section
 * of every HTML page you wish to protect.
 */
(function() {
    // Check a value in sessionStorage. This value is set by the login page upon successful login.
    const isLoggedIn = sessionStorage.getItem('isLoggedIn');

    // If the 'isLoggedIn' item does not exist or is not 'true'...
    if (isLoggedIn !== 'true') {
        // ...redirect the user to the login page.
        // It also passes the current page's path as a 'redirect' URL parameter.
        // This tells the login page where to send the user back to after they log in.
        window.location.href = 'login.html?redirect=' + window.location.pathname;
    }
})();
